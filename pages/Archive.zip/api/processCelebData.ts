import { fetchCelebrityData } from './tmdb';
import { uploadImageToSanity } from './imageUpload';
import { client } from '@/app/utils/sanityClient';
import { markdownToPortableText as parseMarkdownToPT } from '@/utils/markdownToPortableText';

interface CelebrityData {
  name: string;
  dob: string;
  country: string;
  intro: any[];
  image: any;
  metaDescription: string;
  profession: string[];
  ethnicity?: string[];
  eyeColor?: string;
  hairColor?: string;
  height?: string;
  bodyType?: string;
  slug: {
    _type: 'slug';
    current: string;
  };
  powerMeter: number;
  gender: string;
  isDead?: boolean;
  deathDate?: Date;
  expandedBiography?: any[];
  seoKeywords?: string[];
  seoContentBlocks?: Array<{ keyword: string; answer: string }>;
}

const checkIfCelebrityExists = async (name: string) => {
  const query = `*[_type == "facesCelebs" && name == $name][0] { _id, name }`;
  return await client.fetch(query, { name });
};

const fetchGeneratedInfo = async (name: string, infoType: string) => {
  try {
    const response = await fetch('/api/generateCelebInfo', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, infoType }),
    });
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const data = await response.json();
    return data.text?.trim() || '';
  } catch (error) {
    console.error(`[fetchGeneratedInfo] Failed for ${name} (${infoType})`, error);
    return '';
  }
};

const fetchJsonData = async <T>(name: string, prompt: string, key: string): Promise<T | null> => {
  const raw = await fetchGeneratedInfo(name, prompt);
  try {
    const cleaned = raw.replace(/^```json/, '').replace(/```$/, '').trim();
    const parsed = JSON.parse(cleaned);
    return parsed[key] ?? null;
  } catch {
    return null;
  }
};

const fetchDeathInfo = async (name: string, dob: string) => {
  try {
    const response = await fetch('/api/isPersonDead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ personName: name, dob }),
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[fetchDeathInfo] HTTP error for ${name} (DOB: ${dob}): ${response.status} - ${errorText}`);
      return { isDead: false, deathDate: '' }; // Return default on HTTP error
    }
    const data = await response.json();
    // Ensure deathDate is a string, empty if null/undefined/falsey from API
    return { isDead: data.isDead || false, deathDate: data.deathDate || '' }; 
  } catch (error) {
    console.error(`[fetchDeathInfo] Error fetching death info for ${name} (DOB: ${dob}):`, error);
    return { isDead: false, deathDate: '' }; // Return default on other errors
  }
};

export const processCelebrityData = async (tmdbId: string) => {
  const celebrityData = await fetchCelebrityData(tmdbId);
  if (!celebrityData || !celebrityData.profile_path) return null;

  const existing = await checkIfCelebrityExists(celebrityData.name);
  if (existing) return null;

  const name = celebrityData.name;
  const tmdbBiography = celebrityData.biography || '';

  // Country
  let country = '';
  if (celebrityData.place_of_birth) {
    country = celebrityData.place_of_birth.split(',').pop()?.trim() || '';
  } else {
    country = await fetchGeneratedInfo(name, 'just tell the country name of this person');
  }

  // DOB
  let dob = celebrityData.birthday || '';
  if (!dob) {
    // Ensure AI returns empty string if not found, not "nothing"
    dob = await fetchGeneratedInfo(name, 'generate only date of birth in YYYY-MM-DD format. If date of birth not found, return an empty string.');
  }

  // Gender - TMDB: 0 (Not set), 1 (Female), 2 (Male), 3 (Non-binary)
  let genderString: string;
  switch (celebrityData.gender) {
    case 1:
      genderString = 'Female';
      break;
    case 2:
      genderString = 'Male';
      break;
    case 3:
      genderString = 'Non-binary';
      break;
    case 0:
    default:
      genderString = 'Not Specified'; // Or handle as preferred
      break;
  }

  // Professions
  const professionPrompt = `Provide a list of ${name}'s primary professions in a single line, comma-separated. Keep multi-word professions intact.`;
  const professionsRaw = await fetchGeneratedInfo(name, professionPrompt);
  const profession = professionsRaw
    ? professionsRaw.split(',').map((p: string) => p.trim()).filter(Boolean).map((p: string) =>
        genderString === 'Female' && p.toLowerCase() === 'actor' ? 'Actress' : p
      )
    : [];

  const { isDead, deathDate } = await fetchDeathInfo(name, dob);

  const shortIntro = await fetchGeneratedInfo(name, `Create a short and SEO-optimized intro (3 lines) for ${name}. Mention their work, highlights, and country.`);

  // --- SEO keywords FIRST ---
  const preBioSeoKeywordList = await fetchJsonData<string[]>(
    name,
    `You are an SEO expert. Based on public knowledge of ${name}, generate 7–10 high-intent SEO keywords or long-tail queries related to their career, achievements, and identity. Respond as {"seoKeywordsList": ["..."]}`,
    'seoKeywordsList'
  );
  const bioKeywordsComment = preBioSeoKeywordList && preBioSeoKeywordList.length > 0
    ? `<!-- SEO keywords: ${preBioSeoKeywordList.join(', ')} -->\n\n`
    : '';

  const placeOfBirthInfo = celebrityData.place_of_birth ? ` who is known to be from ${celebrityData.place_of_birth}` : '';

  const detailedBiographyMarkdownPrompt = `${bioKeywordsComment}Act as an expert biographer and content creator for a high-quality online platform. Using the provided keywords, creatively and naturally incorporate them throughout the biography without disrupting flow or structure.
Write a comprehensive, detailed, SEO-optimized, and engaging biography of ${name}${placeOfBirthInfo}.
The biography should be informative. Use a neutral tone, avoiding speculation or unverified claims.
The biography should be well-structured using Markdown headings (e.g., '## Early Life and Education', '### Career Breakthrough', '## Philanthropic Work').
Ensure factual accuracy, relying on publicly available and verifiable information. Maintain a neutral, objective, yet captivating tone. Avoid speculation, excessive praise, or unconfirmed rumors. Do not invent information.
Cover the following aspects in detail, where applicable:
- ## Early Life and Background: Include birth date and place (if not already mentioned), family details (if public and relevant), upbringing, and education.
- ## Career Beginnings: Describe their initial foray into their profession(s), early projects, and formative experiences.
- ## Rise to Prominence / Major Career Milestones: Detail breakthrough roles/projects, significant achievements, and turning points in their career.
- ## Notable Works: Highlight the most important works the celebrity is known for.
- ## Awards and Recognition: Highlight major awards, nominations, and honors received.
- ## Personal Life: (Optional, handle with utmost discretion) Briefly touch upon publicly known aspects of their personal life, such as family or significant relationships, if widely reported and non-intrusive.
- ## Philanthropy, Activism, and Other Ventures: Detail any significant charitable work, activism, business ventures, or other notable interests outside their primary profession.
- ## Public Image and Influence: Discuss their public persona, cultural impact, and influence within their field and beyond.
- ## Legacy: Summarize their lasting impact and how they are likely to be remembered.
Aim for a substantial word count (e.g., 800-1500 words), prioritizing depth, quality, and relevance. The goal is a definitive and trustworthy resource. Ensure that all sections are present, even if brief. Do not skip any.
`;

  const detailedBiographyMarkdown = await fetchGeneratedInfo(name, detailedBiographyMarkdownPrompt);

  const expandedBiographyPortableText = detailedBiographyMarkdown
    ? await parseMarkdownToPT(detailedBiographyMarkdown)
    : tmdbBiography ? await parseMarkdownToPT(tmdbBiography) : [];

  const faqPrompt = `From ${name}'s biography, create 4-6 FAQs. Format: {"faqList":[{"question":"...","answer":"..."}]}`;
  const seoContentBlocks = await fetchJsonData<Array<{ question: string; answer: string }>>(name, faqPrompt, 'faqList');

  const { isDead: isDeceased, deathDate: deathDateStringFromApi } = await fetchDeathInfo(name, dob);

  let validDeathDateForSanity: Date | undefined = undefined;
  if (isDeceased && deathDateStringFromApi) {
    if (/^\d{4}-\d{2}-\d{2}$/.test(deathDateStringFromApi)) {
      const parsedDate = new Date(deathDateStringFromApi);
      if (!isNaN(parsedDate.getTime())) {
        validDeathDateForSanity = parsedDate;
      } else {
        console.warn(`[processCelebrityData] Death date string "${deathDateStringFromApi}" for ${name} resulted in an invalid Date object.`);
      }
    } else {
      console.warn(`[processCelebrityData] Death date string "${deathDateStringFromApi}" for ${name} is not in YYYY-MM-DD format.`);
    }
  }
  const processedData: CelebrityData = {
    name,
    dob,
    country,
    intro: [
      {
        _key: 'introKey',
        _type: 'block',
        children: [{ _key: 'spanKey', _type: 'span', marks: [], text: shortIntro || tmdbBiography }],
        markDefs: [],
        style: 'normal',
      },
    ],
    image: await uploadImageToSanity(`https://image.tmdb.org/t/p/original${celebrityData.profile_path}`),
    metaDescription: `Explore ${name}'s biography, height, age, ethnicity, and achievements.`,
    profession,
    slug: {
      _type: 'slug',
      current: name.toLowerCase().replace(/\s+/g, '-'),
    },
    powerMeter: Math.floor(Math.random() * 41) + 70,
    gender: genderString,
    isDead: isDeceased,
    deathDate: validDeathDateForSanity,
    expandedBiography: expandedBiographyPortableText,
    seoKeywords: preBioSeoKeywordList || [],
    seoContentBlocks: seoContentBlocks?.map(faq => ({
      keyword: faq.question,
      answer: faq.answer,
    })) || [],
    ethnicity: (await fetchGeneratedInfo(name, 'just tell ethnicity in one, two or three words'))?.split(','),
    eyeColor: await fetchGeneratedInfo(name, 'just tell eye color type nothing else'),
    hairColor: await fetchGeneratedInfo(name, 'just tell hair color type nothing else'),
    height: await fetchGeneratedInfo(name, `just tell height in format: 5' 10" (170 cm) type nothing else`),
    bodyType: await fetchGeneratedInfo(name, 'just tell body type in one or two words'),
  };

  return await client.create({ _type: 'facesCelebs', ...processedData });
};
